<div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 ">


    

    <div class="grid grid-cols-5 m-6 bg-white shadow-md overflow-hidden sm:rounded-lg">
        <div class="col-span-5 md:col-span-3" style="background: url(<?php echo e(url('img/guest_bg.jpg')); ?>);background-size:cover;background-position: center"></div>
        <div class="col-span-5 md:col-span-2 px-6 py-4">
            <div>
                <?php echo e($logo); ?>

            </div>
            <?php echo e($slot); ?>

        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\ems\resources\views/vendor/jetstream/components/authentication-card.blade.php ENDPATH**/ ?>