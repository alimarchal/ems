<a href="/">
    <img  class="w-24 h-24"  src="<?php echo e(url('img/mdalogo.png')); ?>" alt="AJK Logo">




</a>
<?php /**PATH D:\xampp\htdocs\ems\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>